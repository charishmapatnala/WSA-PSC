import React from "react";
import Search from "./Search";
const Header = () => {
  return (
    <div>
      <nav className="header row sticky-top">
        <img src="/assets/logo.png" alt="logo" className="logo" />
      </nav>
      <div className="search_filter"></div>
        <Search />
      <span className="material-symbols-outlined web_logo">account_circle</span>
    </div>
  );
};

export default Header;
